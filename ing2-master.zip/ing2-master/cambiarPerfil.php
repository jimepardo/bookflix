<?php
	session_start();
	unset($_SESSION['PERFIL']);
	header("Location: seleccionarPerfil.php");
?>