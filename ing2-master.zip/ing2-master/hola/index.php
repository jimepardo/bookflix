<?php
define("directorio", __dir__ ); 
include(directorio."\db.php");
$db= DB::getInstance();
$sql="SELECT sitioActivo 
      FROM sitio
      WHERE idSitio = 1";
$qr=$db->prepare($sql);
$qr->execute(); 
$estadoSitio=$qr->fetch(PDO::FETCH_ASSOC);
if($estadoSitio['sitioActivo'] == 0){
	include(directorio."\login.php");
}
else{
	include(directorio."/noEstaHabilitado.html");
}

?>